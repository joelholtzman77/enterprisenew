Libertine and LaTex

Because of the new and innovative Tex-Variant “XeTex”, which supports Libertine directly even with its OpenType-features, the Libertine-Tex-package is recently not maintained anymore. You’ll find information about the use of Libertine with XeTex on our Website, soon.
